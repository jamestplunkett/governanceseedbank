module.exports = function(eleventyConfig) {
  eleventyConfig.addPassthroughCopy("assets");
  eleventyConfig.addPassthroughCopy("js");
  eleventyConfig.addPassthroughCopy("admin");
  eleventyConfig.addCollection("patternTags", (collection) => {
    const set = new Set();
    collection.getFilteredByGlob("patterns/*.md").forEach(item => {
      (item.data.tags || []).forEach(tag => set.add(tag));
    });
    return [...set].sort();
  });
  eleventyConfig.addCollection("patterns", (api) => api.getFilteredByGlob("patterns/*.md"));
  return { dir: { input: ".", includes: "src", data: "src/_data", output: "_site" } };
};