# Governance Seed Bank – starter site
Upload to GitHub, import to Netlify, and manage content at `/admin`.