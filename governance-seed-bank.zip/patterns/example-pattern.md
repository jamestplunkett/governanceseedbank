---
title: Worker‑Owned Cooperative
status: Proven
tags: [economic, participatory]
essence: Enterprise fully owned and democratically run by its employees; aligns economic incentives with collective wellbeing.
illustration: /assets/img/placeholder.svg
---
## Overview
A worker‑owned cooperative is a business that is **100 % owned and democratically managed by its employees**.